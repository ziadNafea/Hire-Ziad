import {test} from 'node:test';
import assert from 'node:assert/strict';
import {resizeScrollTarget} from '../site/scroll-resize.mjs';
import {galleryState,nextOffset} from '../site/gallery-math.mjs';
import {processScrollState} from '../site/process-math.mjs';
test('resizing keeps the same project progress in both directions',()=>{
 const resized=resizeScrollTarget(1800,1000,2000,980,1200,-800);
 assert.equal(galleryState(resized,980,0,1200,5).progress,.4);
 assert.equal(resizeScrollTarget(resized,980,1200,1000,2000,800),1800);
});
test('resizing keeps the same process stage',()=>{
 for(let index=0;index<5;index++){
  const scroll=1000+(index+.5)*500;
  const resized=resizeScrollTarget(scroll,1000,2500,980,1800,-700);
  assert.equal(processScrollState(resized,980,0,1800,5).index,index);
 }
});
test('positions before and after the section remain stable relative to content',()=>{
 assert.equal(resizeScrollTarget(500,1000,2000,1000,1200,-800),500);
 assert.equal(resizeScrollTarget(3500,1000,2000,1000,1200,-800),2700);
});
test('short-screen fallback releases the pin without retaining artificial travel',()=>{
 assert.equal(resizeScrollTarget(1800,1000,2000,1000,0,-2000),1000);
 assert.equal(resizeScrollTarget(3500,1000,2000,1000,0,-2000),1500);
});
test('gallery controls include the final partial card and reverse navigation',()=>{
 assert.equal(nextOffset([0,520,1040,1560,2080],1560,1,1800),1800);
 assert.equal(nextOffset([0,520,1040,1560,2080],1800,-1,1800),1560);
});
