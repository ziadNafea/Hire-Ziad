# Editing guide

## Main files

| File | Purpose |
| --- | --- |
| `site/index.html` | Sections, visible copy, links, project cards, SVG icon definitions, dialogs |
| `site/style.css` | Typography, layout, responsive styles, colors, hover effects |
| `site/app.js` | Dialogs, contact/CV preview, project data, dock magnification, portrait pressure effect, process UI |
| `site/gallery.js` | Horizontal gallery driven by normal page scrolling |
| `site/gallery-math.mjs` | Gallery progress and next/previous calculations |
| `site/process-scroll.js` | Sticky How I Work section and scroll-driven stages |
| `site/process-math.mjs` | Process scroll-stage calculations |
| `site/process-scene.js` | Three.js scene and stage response |
| `site/projects.json` | Reference copy of the five selected projects |

## Change project content

Update the project cards in `index.html` and the `projects` array at the beginning of `app.js`. Keep the `data-case` index and project order aligned. `projects.json` is a reference export; it is not loaded by the runtime.

## Replace images and CV

- Hero: `site/assets/ziad-designer.webp`
- Shared mockup photograph: `site/assets/laptop-studio.webp`
- Actual project screenshots: `site/assets/screenshots/`
- CV: `site/assets/ziad-nafea-cv.pdf`
- Tool icons: `site/assets/tools/`

Project screenshots are placed into the laptop using the `.mockup-screen` coordinates in CSS. If you replace the laptop template, update those coordinates. Screenshots are shown in grayscale on cards and reveal their original colors on hover. Full project overlays show the actual screenshot.

## Typography and color

Glancyr is loaded locally through `@font-face` in `style.css`. Main color variables are defined in `:root`. The CSS includes responsive and reduced-motion rules. Recent focused adjustments appear toward the end of the stylesheet.

## Interaction behavior

- Work gallery: sticky frame with horizontal movement from normal vertical page scrolling; it releases after the last card.
- How I Work: sticky frame that advances through five stages and updates the 3D scene.
- Reduced motion and short viewports use simpler layouts and direct stage selection.
- Portrait: pointer-sensitive pressure and tilt, with reset on leave/cancel.
- Tool dock: nearby icons enlarge and move aside without visible hover labels.
- CV: preview overlay with download and separate-tab options.

## Checks

From the project root:

```bash
node --check site/app.js
node --check site/gallery.js
node --check site/process-scroll.js
node --check site/process-scene.js
```

The exported source passed syntax, asset/link-reference, and scroll-math checks. Visual browser testing was not available in the creation session.
