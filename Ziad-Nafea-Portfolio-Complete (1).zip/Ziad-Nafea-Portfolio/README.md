# Ziad Nafea — Portfolio

نسخة كاملة من الموقع، بالكود والأصول المستخدمة، مطابقة لتحديث 17 أكتوبر 2026.

## تشغيل الموقع

بعد فك الضغط، افتح Terminal داخل هذا المجلد وشغّل:

```bash
node serve.mjs
```

ثم افتح http://127.0.0.1:8080

يتطلب Node.js 18 أو أحدث. لا يوجد تثبيت حزم ولا خطوة build.

بديل باستخدام Python:

```bash
python -m http.server 8080 --bind 127.0.0.1 --directory site
```

افتح نفس الرابط. استخدم خادمًا محليًا؛ فتح index.html مباشرة عبر file:// لن يحمّل وحدات JavaScript وThree.js كما ينبغي.

## محتويات الملف

- `site/`: الموقع الكامل الجاهز للتشغيل أو الاستضافة كملفات static.
- `site/assets/`: صور الهيرو والموك أب، لقطات المشاريع الحقيقية، أيقونات الأدوات، خط Glancyr، الـCV، وThree.js.
- `design-assets/`: الصور الأصلية النهائية قبل ضغطها للويب، صورك المرجعية، مراجع التصميم، وكل أوزان الخط المرفقة.
- `EDITING.md`: دليل سريع لتعديل المحتوى والتصميم والتفاعلات.
- `FILE-MANIFEST.json`: قائمة الملفات وبصماتها للتحقق من اكتمال النسخة.

الموقع لا يحتوي على backend أو قاعدة بيانات. أزرار التواصل تستخدم البريد والهاتف وLinkedIn وBehance. تفاصيل المشاريع والـCV تفتح داخل نوافذ overlay.

## الاستضافة

ارفع محتويات `site/` إلى مجلد الموقع في أي استضافة static تدعم JavaScript modules وملفات PDF والخطوط. لا يحتاج المشروع إلى أوامر build. النسخة المنشورة سابقًا خاصة؛ هذا الملف يحتوي على الكود والأصول ولا ينسخ صلاحيات الوصول الخاصة بتلك الاستضافة.

## Version

Source commit: `9c0160c8183a50bee59fee8be1185531d04f0665`
Three.js: `0.180.0` — license included at `site/assets/vendor/THREE-LICENSE.txt`.

All runtime modules, fonts, and assets are included locally. External project/contact links still require an internet connection.

## Latest update

Original layered How I Work animation restored. Orange button labels are white. Fluid typography, responsive spacing, resize-aware scrolling and performance improvements retained.

Run scroll checks with `node --test tests/scroll-resize.test.mjs`.
